const bill = document.querySelector("#input-bill") .value;
const tipPercentage = document.querySelector("#input-tip") .value;
const cajaPerson = document.querySelector("#input-people") .value;
const btn1 = document.querySelector("#num1-button") .value;
const btn2 = document.querySelector("#num2-button") .value;
const btn3 = document.querySelector("#num3-button") .value;
const btn4 = document.querySelector("#num4-button") .value;
const btn5 = document.querySelector("#num5-button") .value;






function setCustomTip(tipPercentage) {
    console.log("monto de propina personalizada:", tipPercentage)


}
/* const bill = document.querySelector("#input-bill").value;
const cajaPerson = document.querySelector("#input-people").value;

const btnCall = document.querySelectorAll(".btnCall").value;


function setCustomTip(tipPercentage) {
    tipPercentage.AddEventListener("click", btn1)
    function btn1(){
        const valorBtn1 = parseFloat(btn1.value)
        console.log(valorBtn1)
    }



} */

/* const boton=document.getElementById("#input-tip")

boton.addEventListener("click",pushed) 
let tipAmount = (parsefloat(bill.value) * (tipPercent/100))/parsefloat(numPeople.value)
console.log(tipAmount);
    function pushed(e){
	if(e.target.tagName="BUTTON")
		tipPercent=parseInt(e.target.value)
        console.log(tipPercent)
} 
 */

/* btnCall.forEach( btn => {
    if(btn.localName == "button"){
        btn.addEventListener("click", calculateTip)
                
    }
    else{
        btn.addEventListener("keyup", calculateTip)
    }
});


/* function calculateTip(tipPercentage) {
    
    valorTip=tipPercentage.target.value

} */